package com.example.myapplication;

public class UserInfo {

    public String username;
    public String email;
    public UserInfo(){}
    public UserInfo(String username, String email){
        this.username = username;
        this.email = email;
    }

}
